package in.co.college.att.mgt.exception;


public class DatabaseException  extends Exception
{
	
   public DatabaseException(String msg) {
       super(msg);
   }
}

