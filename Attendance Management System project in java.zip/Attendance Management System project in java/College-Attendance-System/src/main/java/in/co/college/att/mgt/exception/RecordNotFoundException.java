package in.co.college.att.mgt.exception;


public class RecordNotFoundException extends Exception{
	public RecordNotFoundException(String msg) {
		super(msg);

	}
}
