package in.co.college.att.mgt.exception;



public class ApplicationException  extends Exception
{
	
	public ApplicationException(String msg) {
		super(msg);
	}
}
