package in.co.college.att.mgt.bean;


public interface DropdownListBean
{
	public String getKey();

	public String getValue();
}
